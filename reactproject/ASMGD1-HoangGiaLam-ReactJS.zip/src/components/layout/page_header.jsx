
function PageHeader(){
    let style = {
        color: "blue",
        backgroundColor: "red",
    }

    return(
      <>
      <h1 style={style}> Page Header</h1>
      </>
    );
  }
export default PageHeader;