import "./App.css";
import ResponsiveAppBar from "./components/project/app-bar";
import ColorInversionFooter from "./components/project/footer";
import "./styles/index.scss";
import { Outlet } from "react-router-dom";

// let timer;

function App() {
  return (
    <>
      <ResponsiveAppBar />
      <main>
        <Outlet />
      </main>
      <ColorInversionFooter />
    </>
  );
}
export default App;