import { Outlet } from "react-router-dom";
function LayoutPage (){
    return(
        <>
        <Outlet/>
        </>
    );
}
export default LayoutPage;